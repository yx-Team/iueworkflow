let a = '123'

const FIXED = true;

var c = [123,234,34].filter((item)=>{
    return item>100
})